// Що тренується: retries для групи, testInfo.retry, trace 'on-first-retry' і куди він пишеться, testInfo.attach для власних артефактів.
// Запуск: npx playwright test examples/10-debug-flakiness/02-retries-trace-attach.spec.ts
// Очікується: 2 тести: перший «flaky» (падає з першої спроби, проходить із другої; у звіті жовтий), другий зелений із трьома вкладеннями.
// Trace першого тесту: test-results/<папка тесту>-retry1/trace.zip → npx playwright show-trace <шлях>, або з npm run report.
import { test, expect } from '@playwright/test';

const USER = { email: 'user@example.com', password: 'user123' };

test.describe('retries для групи', () => {
  // Кореневий конфіг локально має retries: 0. Для цього прикладу повтор потрібен завжди, тому задаємо його тут.
  test.describe.configure({ retries: 1 });

  test('падає з першої спроби, проходить із другої', async ({ page }, testInfo) => {
    await page.goto('/');
    await testInfo.attach('attempt', { body: `retry=${testInfo.retry}`, contentType: 'text/plain' });

    // Детермінована імітація гонки «раз на N прогонів». Справжню flaky-причину retry не лікує, а ховає:
    // перша спроба все одно падає, і саме її trace (on-first-retry пише trace під час повтору) треба дивитися.
    expect(testInfo.retry, 'перша спроба навмисно падає; дивись test-results/*-retry1/trace.zip').toBeGreaterThan(0);
  });
});

test('attach: JSON, скриншот і файл із outputPath', async ({ page }, testInfo) => {
  await page.request.post('/api/login', { data: USER });
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Tasks' })).toBeVisible();

  // 1. Тіло в пам'яті: стан бекенду на момент перевірки
  const tasks = await (await page.request.get('/api/tasks')).json();
  await testInfo.attach('tasks.json', { body: JSON.stringify(tasks, null, 2), contentType: 'application/json' });

  // 2. Скриншот як вкладення (не плутати зі screenshot: 'only-on-failure' у конфігу, який робиться сам)
  await testInfo.attach('tasks-view', { body: await page.screenshot(), contentType: 'image/png' });

  // 3. Файл у папці тесту: outputPath дає шлях у test-results/<тест>/, attach з path копіює його у звіт
  const logPath = testInfo.outputPath('console.log');
  const lines: string[] = [];
  page.on('console', (m) => lines.push(`[${m.type()}] ${m.text()}`));
  await page.evaluate(() => console.log('hello from page'));
  await expect.poll(() => lines).toContain('[log] hello from page');
  const fs = await import('node:fs/promises');
  await fs.writeFile(logPath, lines.join('\n'));
  await testInfo.attach('console.log', { path: logPath, contentType: 'text/plain' });

  expect(testInfo.attachments.map((a) => a.name)).toEqual(['tasks.json', 'tasks-view', 'console.log']);
});
